// User profile types
export interface UserProfile {
  name: string;
  email: string;
  technicalSkills: string[];
  softSkills: string[];
  interests: string[];
  education: Education;
  experience: Experience;
}

export interface Education {
  degree: string;
  institution: string;
  graduationYear: number;
  major: string;
}

export interface Experience {
  yearsOfExperience: number;
  currentRole?: string;
  currentCompany?: string;
}

// Job recommendation types
export interface JobRecommendation {
  id: string;
  title: string;
  company: string;
  location: string;
  salaryRange: string;
  description: string;
  matchPercentage: number;
  requiredSkills: string[];
  logo: string;
}

// Skill gap types
export interface SkillGap {
  jobId: string;
  missingSkills: MissingSkill[];
  matchScore: number;
}

export interface MissingSkill {
  skill: string;
  importance: number; // 1-10
  category: 'technical' | 'soft';
}

// Certification types
export interface Certification {
  id: string;
  name: string;
  provider: string;
  cost: string;
  duration: string;
  link: string;
  skillsCovered: string[];
  logo: string;
}

// Career insight types
export interface CareerInsight {
  type: 'skillMatch' | 'salaryTrend' | 'careerPath' | 'industryDemand';
  title: string;
  description: string;
  data: any; // Specific data for visualizations
}