import React from 'react';
import { Layout } from './components/Layout';
import { UserProfileForm } from './components/UserProfileForm';
import { RecommendationsPanel } from './components/RecommendationsPanel';
import { CareerContext } from './context/CareerContext';
import { useMockUserState } from './hooks/useMockUserState';

function App() {
  const careerState = useMockUserState();

  return (
    <CareerContext.Provider value={careerState}>
      <Layout>
        {!careerState.hasSubmittedProfile ? (
          <UserProfileForm />
        ) : (
          <RecommendationsPanel />
        )}
      </Layout>
    </CareerContext.Provider>
  );
}

export default App;