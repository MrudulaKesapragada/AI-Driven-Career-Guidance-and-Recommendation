import { SkillGap } from '../types';

export const mockSkillGaps: SkillGap[] = [
  {
    jobId: 'job-1',
    missingSkills: [
      { skill: 'TypeScript', importance: 8, category: 'technical' },
      { skill: 'Redux', importance: 7, category: 'technical' },
      { skill: 'Testing', importance: 6, category: 'technical' }
    ],
    matchScore: 85
  },
  {
    jobId: 'job-2',
    missingSkills: [
      { skill: 'MongoDB', importance: 7, category: 'technical' },
      { skill: 'Express', importance: 6, category: 'technical' },
      { skill: 'Node.js', importance: 9, category: 'technical' }
    ],
    matchScore: 78
  },
  {
    jobId: 'job-3',
    missingSkills: [
      { skill: 'Python', importance: 9, category: 'technical' },
      { skill: 'Machine Learning', importance: 8, category: 'technical' },
      { skill: 'SQL', importance: 7, category: 'technical' },
      { skill: 'Statistics', importance: 8, category: 'technical' }
    ],
    matchScore: 65
  },
  {
    jobId: 'job-4',
    missingSkills: [
      { skill: 'Docker', importance: 8, category: 'technical' },
      { skill: 'Kubernetes', importance: 9, category: 'technical' },
      { skill: 'CI/CD', importance: 7, category: 'technical' }
    ],
    matchScore: 70
  },
  {
    jobId: 'job-5',
    missingSkills: [
      { skill: 'UI Design', importance: 9, category: 'technical' },
      { skill: 'UX Design', importance: 9, category: 'technical' },
      { skill: 'Figma', importance: 7, category: 'technical' },
      { skill: 'User Research', importance: 6, category: 'technical' },
      { skill: 'Creativity', importance: 8, category: 'soft' }
    ],
    matchScore: 60
  },
  {
    jobId: 'job-6',
    missingSkills: [
      { skill: 'Solidity', importance: 9, category: 'technical' },
      { skill: 'Blockchain', importance: 9, category: 'technical' },
      { skill: 'Web3.js', importance: 8, category: 'technical' },
      { skill: 'Ethereum', importance: 8, category: 'technical' }
    ],
    matchScore: 55
  },
  {
    jobId: 'job-7',
    missingSkills: [
      { skill: 'Product Management', importance: 9, category: 'technical' },
      { skill: 'Leadership', importance: 8, category: 'soft' },
      { skill: 'Analytics', importance: 7, category: 'technical' },
      { skill: 'Project Management', importance: 8, category: 'technical' }
    ],
    matchScore: 68
  },
  {
    jobId: 'job-8',
    missingSkills: [
      { skill: 'Azure', importance: 8, category: 'technical' },
      { skill: 'Cloud Architecture', importance: 9, category: 'technical' },
      { skill: 'Networking', importance: 7, category: 'technical' },
      { skill: 'System Design', importance: 8, category: 'technical' }
    ],
    matchScore: 72
  }
];