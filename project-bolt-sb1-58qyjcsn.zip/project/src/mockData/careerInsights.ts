import { CareerInsight } from '../types';

export const mockCareerInsights: CareerInsight[] = [
  {
    type: 'skillMatch',
    title: 'Your Skills vs Market Demand',
    description: 'Analysis of your skills compared to current market requirements',
    data: {
      userSkills: [
        { name: 'JavaScript', proficiency: 85 },
        { name: 'React', proficiency: 90 },
        { name: 'Node.js', proficiency: 75 },
        { name: 'Python', proficiency: 60 },
        { name: 'AWS', proficiency: 70 }
      ],
      marketDemand: [
        { name: 'JavaScript', demand: 95 },
        { name: 'React', demand: 92 },
        { name: 'Node.js', demand: 88 },
        { name: 'Python', demand: 85 },
        { name: 'AWS', demand: 90 }
      ]
    }
  },
  {
    type: 'salaryTrend',
    title: 'Salary Trends by Experience',
    description: 'Current salary trends based on experience levels in your domain',
    data: {
      trends: [
        { year: '0-2', salary: 500000 },
        { year: '2-5', salary: 1200000 },
        { year: '5-8', salary: 2000000 },
        { year: '8-12', salary: 2800000 },
        { year: '12+', salary: 3500000 }
      ]
    }
  },
  {
    type: 'industryDemand',
    title: 'Top Skills in Demand',
    description: 'Most sought-after skills with their growth trends',
    data: {
      skills: [
        { name: 'Cloud Computing', demand: 95, growth: '+25%' },
        { name: 'AI/ML', demand: 92, growth: '+30%' },
        { name: 'DevOps', demand: 88, growth: '+20%' },
        { name: 'Data Science', demand: 85, growth: '+22%' },
        { name: 'Cybersecurity', demand: 90, growth: '+28%' }
      ]
    }
  }
];