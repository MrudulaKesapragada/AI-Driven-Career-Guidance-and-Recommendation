import { JobRecommendation } from '../types';

export const mockJobRecommendations: JobRecommendation[] = [
  {
    id: 'job-1',
    title: 'Senior Frontend Developer',
    company: 'Microsoft India',
    location: 'Bangalore, India',
    salaryRange: '₹22-30 LPA',
    description: 'Join our dynamic team to build modern, responsive web applications using React, TypeScript, and cutting-edge web technologies. You\'ll work on products used by millions of customers worldwide.',
    matchPercentage: 85,
    requiredSkills: ['JavaScript', 'React', 'TypeScript', 'HTML/CSS', 'Redux', 'Testing', 'Communication'],
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Microsoft_logo.svg/2048px-Microsoft_logo.svg.png',
    applyLink: 'https://careers.microsoft.com/professionals/us/en/search-results',
    benefits: [
      'Health Insurance',
      'Stock Options',
      'Flexible Work Hours',
      'Remote Work Options'
    ],
    responsibilities: [
      'Lead frontend development initiatives',
      'Mentor junior developers',
      'Architect scalable solutions',
      'Collaborate with product teams'
    ]
  },
  {
    id: 'job-2',
    title: 'Full Stack Developer',
    company: 'Amazon India',
    location: 'Hyderabad, India',
    salaryRange: '₹20-28 LPA',
    description: 'Build scalable web applications and services for Amazon\'s e-commerce platform. Work with cutting-edge technologies and contribute to projects that impact millions of customers.',
    matchPercentage: 78,
    requiredSkills: ['Node.js', 'React', 'MongoDB', 'AWS', 'TypeScript', 'System Design'],
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/2560px-Amazon_logo.svg.png',
    applyLink: 'https://www.amazon.jobs/en/locations/india',
    benefits: [
      'Health Insurance',
      'RSUs',
      'Relocation Assistance',
      'Learning Allowance'
    ],
    responsibilities: [
      'Develop full-stack applications',
      'Design scalable architectures',
      'Optimize application performance',
      'Write clean, maintainable code'
    ]
  },
  {
    id: 'job-3',
    title: 'Machine Learning Engineer',
    company: 'Google India',
    location: 'Bangalore, India',
    salaryRange: '₹25-35 LPA',
    description: 'Join Google\'s ML team to develop and deploy machine learning models that power Google\'s products. Work on cutting-edge AI technologies and solve complex problems.',
    matchPercentage: 72,
    requiredSkills: ['Python', 'Machine Learning', 'TensorFlow', 'Deep Learning', 'SQL', 'Statistics'],
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/2880px-Google_2015_logo.svg.png',
    applyLink: 'https://careers.google.com/jobs/results/',
    benefits: [
      'Comprehensive Health Coverage',
      'Stock Options',
      'Free Meals',
      'Gym Membership'
    ],
    responsibilities: [
      'Develop ML models',
      'Optimize model performance',
      'Research new ML techniques',
      'Deploy models to production'
    ]
  }
];