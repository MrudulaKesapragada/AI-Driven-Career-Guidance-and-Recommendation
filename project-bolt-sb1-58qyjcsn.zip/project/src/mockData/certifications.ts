import { Certification } from '../types';

export const mockCertifications: Certification[] = [
  {
    id: 'cert-1',
    name: 'AWS Certified Solutions Architect',
    provider: 'AWS',
    cost: '₹14,500',
    duration: '6 weeks',
    link: 'https://aws.amazon.com/certification/certified-solutions-architect-associate/',
    skillsCovered: ['AWS', 'Cloud Computing', 'System Design', 'DevOps'],
    logo: 'https://images.pexels.com/photos/12339539/pexels-photo-12339539.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-2',
    name: 'Certified Kubernetes Administrator',
    provider: 'CNCF',
    cost: '₹12,000',
    duration: '8 weeks',
    link: 'https://www.cncf.io/certification/cka/',
    skillsCovered: ['Kubernetes', 'Docker', 'DevOps', 'Cloud Native'],
    logo: 'https://images.pexels.com/photos/5926382/pexels-photo-5926382.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-3',
    name: 'Machine Learning Specialization',
    provider: 'Coursera',
    cost: '₹3,500/month',
    duration: '3 months',
    link: 'https://www.coursera.org/specializations/machine-learning-introduction',
    skillsCovered: ['Machine Learning', 'Python', 'Data Analysis', 'TensorFlow'],
    logo: 'https://images.pexels.com/photos/11035539/pexels-photo-11035539.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-4',
    name: 'Full Stack Web Development',
    provider: 'NPTEL',
    cost: 'Free',
    duration: '12 weeks',
    link: 'https://nptel.ac.in/',
    skillsCovered: ['JavaScript', 'React', 'Node.js', 'MongoDB'],
    logo: 'https://images.pexels.com/photos/11035386/pexels-photo-11035386.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-5',
    name: 'Advanced Data Structures & Algorithms',
    provider: 'GeeksforGeeks',
    cost: '₹9,999',
    duration: '10 weeks',
    link: 'https://www.geeksforgeeks.org/courses/',
    skillsCovered: ['Data Structures', 'Algorithms', 'Problem Solving', 'C++'],
    logo: 'https://images.pexels.com/photos/7516275/pexels-photo-7516275.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-6',
    name: 'Microsoft Azure Fundamentals (AZ-900)',
    provider: 'Microsoft',
    cost: '₹4,800',
    duration: '4 weeks',
    link: 'https://learn.microsoft.com/en-us/certifications/exams/az-900',
    skillsCovered: ['Azure', 'Cloud Computing', 'IaaS', 'PaaS'],
    logo: 'https://images.pexels.com/photos/5052943/pexels-photo-5052943.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-7',
    name: 'Python for Data Science',
    provider: 'IIT Madras Online',
    cost: '₹1,000',
    duration: '8 weeks',
    link: 'https://onlinecourses.nptel.ac.in/',
    skillsCovered: ['Python', 'Data Analysis', 'Pandas', 'NumPy'],
    logo: 'https://images.pexels.com/photos/5926393/pexels-photo-5926393.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-8',
    name: 'UI/UX Design Specialization',
    provider: 'Udemy',
    cost: '₹3,999',
    duration: '20 hours',
    link: 'https://www.udemy.com/',
    skillsCovered: ['UI Design', 'UX Design', 'Figma', 'User Research'],
    logo: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-9',
    name: 'Product Management Certification',
    provider: 'Upgrad',
    cost: '₹45,000',
    duration: '6 months',
    link: 'https://www.upgrad.com/',
    skillsCovered: ['Product Management', 'Leadership', 'Project Management', 'Communication'],
    logo: 'https://images.pexels.com/photos/6325984/pexels-photo-6325984.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-10',
    name: 'Digital Marketing Specialization',
    provider: 'Simplilearn',
    cost: '₹25,000',
    duration: '3 months',
    link: 'https://www.simplilearn.com/',
    skillsCovered: ['Digital Marketing', 'SEO', 'Social Media Marketing', 'Analytics'],
    logo: 'https://images.pexels.com/photos/905163/pexels-photo-905163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-11',
    name: 'Java Programming Masterclass',
    provider: 'Udemy',
    cost: '₹4,500',
    duration: '80 hours',
    link: 'https://www.udemy.com/',
    skillsCovered: ['Java', 'Spring Boot', 'Hibernate', 'Microservices'],
    logo: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: 'cert-12',
    name: 'Cybersecurity Fundamentals',
    provider: 'Great Learning',
    cost: '₹30,000',
    duration: '4 months',
    link: 'https://www.greatlearning.in/',
    skillsCovered: ['Cybersecurity', 'Network Security', 'Ethical Hacking', 'Security Protocols'],
    logo: 'https://images.pexels.com/photos/5380642/pexels-photo-5380642.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];