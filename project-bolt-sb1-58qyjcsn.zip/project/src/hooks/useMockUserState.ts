import { useState, useCallback } from 'react';
import { 
  UserProfile, 
  JobRecommendation,
  SkillGap,
  Certification,
  CareerInsight
} from '../types';
import { mockJobRecommendations } from '../mockData/jobRecommendations';
import { mockSkillGaps } from '../mockData/skillGaps';
import { mockCertifications } from '../mockData/certifications';
import { mockCareerInsights } from '../mockData/careerInsights';

export const useMockUserState = () => {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [jobRecommendations, setJobRecommendations] = useState<JobRecommendation[]>([]);
  const [skillGaps, setSkillGaps] = useState<SkillGap[]>([]);
  const [certifications, setCertifications] = useState<Certification[]>([]);
  const [careerInsights, setCareerInsights] = useState<CareerInsight[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSubmittedProfile, setHasSubmittedProfile] = useState(false);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);

  const updateUserProfile = useCallback((profile: UserProfile) => {
    setIsLoading(true);
    setUserProfile(profile);
    
    // Simulate API call delay
    setTimeout(() => {
      // Get all user skills
      const userSkills = new Set([
        ...profile.technicalSkills,
        ...profile.softSkills
      ]);
      
      // Calculate job matches with weighted scoring
      const scoredJobs = mockJobRecommendations.map(job => {
        // Calculate skill match
        const matchedSkills = job.requiredSkills.filter(skill => 
          userSkills.has(skill)
        ).length;
        
        // Calculate experience match (0-1)
        const expMatch = Math.min(profile.experience.yearsOfExperience / 5, 1);
        
        // Calculate interest match
        const interestMatch = profile.interests.some(interest => 
          job.title.toLowerCase().includes(interest.toLowerCase()) ||
          job.description.toLowerCase().includes(interest.toLowerCase())
        ) ? 1 : 0;
        
        // Weighted score calculation
        const skillScore = (matchedSkills / job.requiredSkills.length) * 0.6;
        const expScore = expMatch * 0.2;
        const interestScore = interestMatch * 0.2;
        
        const totalScore = (skillScore + expScore + interestScore) * 100;
        
        return {
          ...job,
          matchPercentage: Math.round(totalScore)
        };
      });
      
      // Sort by match percentage and filter out low matches
      const matchedJobs = scoredJobs
        .sort((a, b) => b.matchPercentage - a.matchPercentage)
        .filter(job => job.matchPercentage >= 30);
      
      // If no matches found, include some default recommendations
      const finalJobs = matchedJobs.length > 0 ? matchedJobs : 
        mockJobRecommendations
          .slice(0, 3)
          .map(job => ({
            ...job,
            matchPercentage: 30
          }));
      
      // Get skill gaps for matched jobs
      const relevantSkillGaps = mockSkillGaps.filter(gap => 
        finalJobs.some(job => job.id === gap.jobId)
      );
      
      // Get missing skills
      const missingSkills = new Set<string>();
      relevantSkillGaps.forEach(gap => {
        gap.missingSkills.forEach(skill => {
          missingSkills.add(skill.skill);
        });
      });
      
      // Filter and sort certifications by relevance
      const relevantCertifications = mockCertifications
        .filter(cert => 
          cert.skillsCovered.some(skill => missingSkills.has(skill))
        )
        .map(cert => ({
          ...cert,
          relevance: cert.skillsCovered.filter(skill => 
            missingSkills.has(skill)
          ).length
        }))
        .sort((a, b) => b.relevance - a.relevance);
      
      setJobRecommendations(finalJobs);
      setSkillGaps(relevantSkillGaps);
      setCertifications(relevantCertifications);
      setCareerInsights(mockCareerInsights);
      setIsLoading(false);
      setHasSubmittedProfile(true);
      
      if (finalJobs.length > 0) {
        setSelectedJobId(finalJobs[0].id);
      }
    }, 1500);
  }, []);
  
  const resetProfile = useCallback(() => {
    setUserProfile(null);
    setJobRecommendations([]);
    setSkillGaps([]);
    setCertifications([]);
    setCareerInsights([]);
    setHasSubmittedProfile(false);
    setSelectedJobId(null);
  }, []);

  return {
    userProfile,
    jobRecommendations,
    skillGaps,
    certifications,
    careerInsights,
    isLoading,
    hasSubmittedProfile,
    selectedJobId,
    updateUserProfile,
    resetProfile
  };
};