import { createContext, useContext } from 'react';
import { 
  UserProfile, 
  JobRecommendation,
  SkillGap, 
  Certification,
  CareerInsight
} from '../types';

interface CareerContextType {
  userProfile: UserProfile | null;
  jobRecommendations: JobRecommendation[];
  skillGaps: SkillGap[];
  certifications: Certification[];
  careerInsights: CareerInsight[];
  isLoading: boolean;
  hasSubmittedProfile: boolean;
  selectedJobId: string | null;
  updateUserProfile: (profile: UserProfile) => void;
  resetProfile: () => void;
}

const defaultContext: CareerContextType = {
  userProfile: null,
  jobRecommendations: [],
  skillGaps: [],
  certifications: [],
  careerInsights: [],
  isLoading: false,
  hasSubmittedProfile: false,
  selectedJobId: null,
  updateUserProfile: () => {},
  resetProfile: () => {},
};

export const CareerContext = createContext<CareerContextType>(defaultContext);

export const useCareerContext = () => useContext(CareerContext);